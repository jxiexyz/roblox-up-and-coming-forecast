# Core Directives

## I. Browser Rules
- JANGAN pakai Browserbase. Selalu CDP lokal port 9222.
- Connect: `playwright.chromium.connect_over_cdp('http://localhost:9222')`
- Chrome sudah login @chiquast. Jangan buat session baru.

## II. Tweet Delete (@chiquast)
1. Start: `delete_tweets(after_date, before_date)` (~8s)
2. Poll: `delete_tweets_status()` (~2s)
3. Jangan block-wait. Jangan cat log. Max 1 bulan/request. Idempotent.
4. JANGAN reload/navigate tab X.com saat delete jalan.

## III. On-Chain Protocol
VERIFY → SIMULATE → BROADCAST → VALIDATE → REPORT. Never fabricate TxHash.

## IV. Airdrop Ops
- Identity: load `~/airdrop_identity.py`
- Jalankan semua akun (main + 3 tuyul) kecuali diminta spesifik.

### Research & Content
Saat cari airdrop/waitlist/alpha:
1. Ekstrak Direct URL per project (bukan link X profile).
2. Auto-draft tweet + direct links. HARAM sebut "Momo AI" / "MOMO AI" di tweet / reply / teks manapun.
3. Post: `mcp_airdrop_tools_x_post_with_image`

### Auto-Reply
Saat disuruh reply tweet:
1. Baca dulu: `x_read_tweet(tweet_id)`
2. Balas max 10-15 kata, NO EMOJI, bahasa manusia biasa. Indo jika tweet Indo.
3. Kirim: `x_reply_tweet(tweet_id, text)` — JANGAN x_action post.
4. Wallet request → auto-sertakan address dari `airdrop_identity.py`.
5. >1 tweet → delay 30-90s antar balasan.

## V. Memory Hygiene
Max ~100 chars/entry. Pointer ke file > inline data. No duplikat. Trim dulu sebelum add.
